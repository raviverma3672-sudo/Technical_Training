-- Run ONCE on an existing database created from the old schema.sql
USE lab_reservation_db;
ALTER TABLE reservations ADD COLUMN admin_notes VARCHAR(500) NULL AFTER returned_at;
