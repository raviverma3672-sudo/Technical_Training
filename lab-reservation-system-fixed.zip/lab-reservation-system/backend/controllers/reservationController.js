const pool = require('../config/db');
const { createReservation } = require('../services/reservationService');
const { createError } = require('../middlewares/errorMiddleware');

const VALID_STATUS_TRANSITIONS = {
  PENDING: ['APPROVED', 'REJECTED'],
  APPROVED: ['ACTIVE', 'REJECTED'],
  ACTIVE: ['COMPLETED'],
};

const reserve = async (req, res, next) => {
  try {
    const { equipment_id, start_time, end_time, purpose } = req.body;

    if (!equipment_id) {
      throw createError('equipment_id is required.', 400, 'VALIDATION_ERROR');
    }

    const reservation = await createReservation({
      user_id: req.user.id,
      equipment_id: parseInt(equipment_id),
      start_time,
      end_time,
      purpose,
    });

    return res.status(201).json({
      success: true,
      message: 'Reservation request submitted successfully. Awaiting admin approval.',
      data: { reservation },
      error: null,
    });
  } catch (err) {
    next(err);
  }
};

const parseStatusList = (raw) => {
  if (!raw) return [];
  const list = Array.isArray(raw) ? raw : String(raw).split(',');
  const allowed = ['PENDING', 'APPROVED', 'ACTIVE', 'COMPLETED', 'CANCELLED', 'REJECTED'];
  const cleaned = list.map((s) => String(s).trim().toUpperCase()).filter(Boolean);
  const invalid = cleaned.find((s) => !allowed.includes(s));
  if (invalid) throw createError(`Invalid status filter "${invalid}".`, 400, 'VALIDATION_ERROR');
  return cleaned;
};

const getMyReservations = async (req, res, next) => {
  try {
    const statuses = parseStatusList(req.query.status);
    const pageNum = Math.max(1, parseInt(req.query.page) || 1);
    const limitNum = Math.min(100, Math.max(1, parseInt(req.query.limit) || 20));
    const offset = (pageNum - 1) * limitNum;

    let where = 'WHERE r.user_id = ?';
    const params = [req.user.id];
    if (statuses.length > 0) {
      where += ` AND r.status IN (${statuses.map(() => '?').join(',')})`;
      params.push(...statuses);
    }

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) AS total FROM reservations r ${where}`,
      params
    );

    const [rows] = await pool.query(
      `SELECT r.*, e.name AS equipment_name, e.category, e.lab_location, e.serial_number
       FROM reservations r
       JOIN equipment e ON r.equipment_id = e.id
       ${where}
       ORDER BY r.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, limitNum, offset]
    );

    return res.status(200).json({
      success: true,
      message: 'Your reservations retrieved.',
      data: {
        reservations: rows,
        pagination: { total, page: pageNum, limit: limitNum, totalPages: Math.ceil(total / limitNum) },
      },
      error: null,
    });
  } catch (err) {
    next(err);
  }
};

const cancelReservation = async (req, res, next) => {
  try {
    const { id } = req.params;
    const resId = parseInt(id);

    if (!Number.isInteger(resId)) {
      throw createError('Invalid reservation ID.', 400, 'VALIDATION_ERROR');
    }

    const [rows] = await pool.query(
      'SELECT * FROM reservations WHERE id = ? AND user_id = ?',
      [resId, req.user.id]
    );

    if (rows.length === 0) {
      throw createError('Reservation not found or you do not have permission to cancel it.', 404, 'NOT_FOUND');
    }

    const res_record = rows[0];

    if (!['PENDING', 'APPROVED'].includes(res_record.status)) {
      throw createError(
        `Cannot cancel a reservation with status "${res_record.status}". Only PENDING or APPROVED reservations can be cancelled.`,
        409,
        'INVALID_STATUS_TRANSITION'
      );
    }

    await pool.query(
      'UPDATE reservations SET status = ? WHERE id = ?',
      ['CANCELLED', resId]
    );

    return res.status(200).json({
      success: true,
      message: 'Reservation cancelled successfully.',
      data: null,
      error: null,
    });
  } catch (err) {
    next(err);
  }
};

const getAllReservations = async (req, res, next) => {
  try {
    const { status, search, equipment_id, user_id, page = 1, limit = 50 } = req.query;

    const pageNum = Math.max(1, parseInt(page) || 1);
    const limitNum = Math.min(200, Math.max(1, parseInt(limit) || 50));
    const offset = (pageNum - 1) * limitNum;

    let conditions = [];
    let params = [];

    const statuses = parseStatusList(status);
    if (statuses.length > 0) {
      conditions.push(`r.status IN (${statuses.map(() => '?').join(',')})`);
      params.push(...statuses);
    }
    if (search && String(search).trim()) {
      conditions.push('(e.name LIKE ? OR u.name LIKE ? OR u.email LIKE ?)');
      const term = `%${String(search).trim()}%`;
      params.push(term, term, term);
    }
    if (equipment_id) {
      conditions.push('r.equipment_id = ?');
      params.push(parseInt(equipment_id));
    }
    if (user_id) {
      conditions.push('r.user_id = ?');
      params.push(parseInt(user_id));
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const [countResult] = await pool.query(
      `SELECT COUNT(*) AS total FROM reservations r
       JOIN equipment e ON r.equipment_id = e.id
       JOIN users u ON r.user_id = u.id
       ${whereClause}`,
      params
    );
    const total = countResult[0].total;

    const [rows] = await pool.query(
      `SELECT r.*, e.name AS equipment_name, e.category, e.lab_location, e.serial_number,
              u.name AS user_name, u.email AS user_email
       FROM reservations r
       JOIN equipment e ON r.equipment_id = e.id
       JOIN users u ON r.user_id = u.id
       ${whereClause}
       ORDER BY r.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, limitNum, offset]
    );

    return res.status(200).json({
      success: true,
      message: 'All reservations retrieved.',
      data: {
        reservations: rows,
        pagination: { total, page: pageNum, limit: limitNum, totalPages: Math.ceil(total / limitNum) },
      },
      error: null,
    });
  } catch (err) {
    next(err);
  }
};

const updateReservationStatus = async (req, res, next) => {
  const conn = await pool.getConnection();
  try {
    const resId = parseInt(req.params.id);
    const { status, admin_notes } = req.body;

    if (!Number.isInteger(resId)) {
      throw createError('Invalid reservation ID.', 400, 'VALIDATION_ERROR');
    }
    if (!status) {
      throw createError('Status is required.', 400, 'VALIDATION_ERROR');
    }

    const newStatus = String(status).toUpperCase();
    const notes = admin_notes ? String(admin_notes).trim().slice(0, 500) : null;

    if (newStatus === 'REJECTED' && !notes) {
      throw createError('A reason is required when rejecting a reservation.', 400, 'VALIDATION_ERROR');
    }

    await conn.beginTransaction();

    // Lock the reservation AND its equipment row so approvals serialise with new bookings
    const [rows] = await conn.query(
      `SELECT r.*, e.name AS equipment_name, e.status AS equipment_status
       FROM reservations r
       JOIN equipment e ON r.equipment_id = e.id
       WHERE r.id = ?
       FOR UPDATE`,
      [resId]
    );

    if (rows.length === 0) {
      throw createError('Reservation not found.', 404, 'NOT_FOUND');
    }

    const reservation = rows[0];
    const allowedTransitions = VALID_STATUS_TRANSITIONS[reservation.status] || [];

    if (!allowedTransitions.includes(newStatus)) {
      throw createError(
        `Invalid status transition from "${reservation.status}" to "${newStatus}". Allowed: ${allowedTransitions.join(', ') || 'none'}.`,
        409,
        'INVALID_STATUS_TRANSITION'
      );
    }

    // FIX: two PENDING requests can overlap; re-check conflicts at approval time
    if (newStatus === 'APPROVED') {
      if (reservation.equipment_status !== 'AVAILABLE') {
        throw createError(
          `Cannot approve: equipment is currently ${reservation.equipment_status}.`,
          409,
          'EQUIPMENT_NOT_AVAILABLE'
        );
      }
      const [conflicts] = await conn.query(
        `SELECT id FROM reservations
         WHERE equipment_id = ? AND id <> ?
           AND status IN ('APPROVED', 'ACTIVE')
           AND NOT (end_time <= ? OR start_time >= ?)`,
        [reservation.equipment_id, resId, reservation.start_time, reservation.end_time]
      );
      if (conflicts.length > 0) {
        throw createError(
          'Cannot approve: this time slot now overlaps an already approved reservation.',
          409,
          'TIME_SLOT_CONFLICT'
        );
      }
    }

    const returnedAt = newStatus === 'COMPLETED' ? new Date() : null;

    await conn.query(
      `UPDATE reservations
       SET status = ?,
           returned_at = COALESCE(?, returned_at),
           admin_notes = COALESCE(?, admin_notes)
       WHERE id = ?`,
      [newStatus, returnedAt, notes, resId]
    );

    await conn.commit();

    const [updated] = await pool.query(
      `SELECT r.*, e.name AS equipment_name, u.name AS user_name FROM reservations r
       JOIN equipment e ON r.equipment_id = e.id
       JOIN users u ON r.user_id = u.id
       WHERE r.id = ?`,
      [resId]
    );

    return res.status(200).json({
      success: true,
      message: `Reservation status updated to "${newStatus}".`,
      data: { reservation: updated[0] },
      error: null,
    });
  } catch (err) {
    try { await conn.rollback(); } catch (_) { /* ignore */ }
    next(err);
  } finally {
    conn.release();
  }
};

const getMetrics = async (req, res, next) => {
  try {
    const [[totalEquipment]] = await pool.query('SELECT COUNT(*) AS count FROM equipment WHERE status != ?', ['RETIRED']);
    const [[currentlyLoaned]] = await pool.query(
      "SELECT COUNT(*) AS count FROM reservations WHERE status IN ('ACTIVE')"
    );
    const [[pendingApprovals]] = await pool.query(
      "SELECT COUNT(*) AS count FROM reservations WHERE status = 'PENDING'"
    );
    const [[maintenanceCount]] = await pool.query(
      "SELECT COUNT(*) AS count FROM equipment WHERE status = 'MAINTENANCE'"
    );
    const [[totalUsers]] = await pool.query("SELECT COUNT(*) AS count FROM users WHERE role = 'USER'");
    const [[approvedToday]] = await pool.query(
      "SELECT COUNT(*) AS count FROM reservations WHERE status = 'APPROVED' AND DATE(created_at) = CURDATE()"
    );

    return res.status(200).json({
      success: true,
      message: 'System metrics retrieved.',
      data: {
        metrics: {
          totalEquipment: totalEquipment.count,
          currentlyLoaned: currentlyLoaned.count,
          pendingApprovals: pendingApprovals.count,
          maintenanceCount: maintenanceCount.count,
          totalUsers: totalUsers.count,
          approvedToday: approvedToday.count,
        },
      },
      error: null,
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  reserve,
  getMyReservations,
  cancelReservation,
  getAllReservations,
  updateReservationStatus,
  getMetrics,
};
